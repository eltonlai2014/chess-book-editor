"""Copyright (C) 2024  walker li <walker8088@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

# pylint: disable=too-many-locals,too-many-branches,too-many-statements

import struct
from typing import Tuple

from .board import ChessBoard
from .common import GAME_RESULT_MAP, SIDE_RED, append_move_to_book, get_fench_color

# XQF 协议常量
_XQF_HEADER_SIZE = 0x400  # XQF 文件头大小 (1024 字节)
_XQF_MOVE_FROM_OFFSET = 0x18  # 起始位置偏移量
_XQF_MOVE_TO_OFFSET = 0x20  # 目标位置偏移量
_XQF_STEP_FLAG_MASK = 0xE0  # 走子标志掩码
_XQF_STEP_HAS_ANNO = 0x20  # 有注释标志
_XQF_STEP_HAS_NEXT = 0x80  # 有下一步标志
_XQF_STEP_HAS_VAR = 0x40  # 有变招标志


# -----------------------------------------------------#
def _xqf_decode_pos(man_pos):
    """将单个压缩的棋子位置整数解码为 (x, y) 坐标。

    XQF 中棋子位置一般以十进制编码，函数将其拆为列和行。
    """
    return (int(man_pos // 10), man_pos % 10)


def _xqf_decode_pos2(man_pos):
    """将包含两个压缩位置的元组解码为 ((from_x,from_y),(to_x,to_y))。"""
    return (
        _xqf_decode_pos(man_pos[0]),
        _xqf_decode_pos(man_pos[1]),
    )


# -----------------------------------------------------#
class XQFKey:
    """承载 XQF 文件中用于解密走子和注释的密钥字段的简单容器。"""

    # pylint: disable=invalid-name

    def __init__(self):
        """初始化密钥容器。"""
        self.KeyXY = None
        self.KeyXYf = None
        self.KeyXYt = None
        self.KeyRMKSize = None
        self.FKeyBytes = None
        self.F32Keys = None


# -----------------------------------------------------#
class XQFBuffDecoder:
    """对 XQF 中走子数据区的字节流提供顺序读取辅助。

    提供按字节读取、按长度解码字符串以及读取 4 字节整数的便利方法，
    以便在解析走子（steps）时按顺序消费缓冲区。
    """

    def __init__(self, buffer):
        self.buffer = buffer
        self.index = 0
        self.length = len(buffer)

    def _read(self, size):
        """内部方法：从当前索引读 `size` 字节并推进索引。"""
        start = self.index
        stop = min(self.index + size, self.length)

        self.index = stop
        return self.buffer[start:stop]

    def read_str(self, size, coding="GB18030"):
        """读取指定字节并按给定编码尝试解码为字符串，失败返回 None。"""

        buff = self._read(size)

        try:
            ret = buff.decode(coding)
        except (UnicodeDecodeError, ValueError):
            ret = None

        return ret

    def read_bytes(self, size):
        """读取指定字节并返回 bytearray。"""
        return bytearray(self._read(size))

    def read_int(self):
        """读取 4 字节并按小端序返回一个整数。"""
        data = self.read_bytes(4)
        return data[0] + (data[1] << 8) + (data[2] << 16) + (data[3] << 24)


# -------------------------------------------------#
# Pascal code here from XQFRW.pas
# KeyMask   : dTByte;                         // 加密掩码
# ProductId : dTDWord;                        // 产品号(厂商的产品号)
# KeyOrA    : dTByte;
# KeyOrB    : dTByte;
# KeyOrC    : dTByte;
# KeyOrD    : dTByte;
# KeysSum   : dTByte;                         // 加密的钥匙和
# KeyXY     : dTByte;                         // 棋子布局位置钥匙
# KeyXYf    : dTByte;                         // 棋谱起点钥匙
# KeyXYt    : dTByte;                         // 棋谱终点钥匙


def _init_decrypt_key(buff_str):
    """根据 XQF 头部的密钥字段计算并返回用于解密数据的 `XQFKey` 对象。"""

    keys = XQFKey()
    (
        HEAD_KeyMask,
        _HEAD_ProductId,
        HEAD_KeyOrA,
        HEAD_KeyOrB,
        HEAD_KeyOrC,
        HEAD_KeyOrD,
        HEAD_KeysSum,
        HEAD_KeyXY,
        HEAD_KeyXYf,
        HEAD_KeyXYt,
    ) = struct.unpack("<BIBBBBBBBB", buff_str)
    # 以下是密码计算公式

    # 棋子32个位置加密因子
    bKey = HEAD_KeyXY
    keys.KeyXY = ((((((bKey * bKey) * 3 + 9) * 3 + 8) * 2 + 1) * 3 + 8) * bKey) & 0xFF

    # 棋谱加密因子(起点)
    bKey = HEAD_KeyXYf
    keys.KeyXYf = (
        (((((bKey * bKey) * 3 + 9) * 3 + 8) * 2 + 1) * 3 + 8) * keys.KeyXY
    ) & 0xFF

    # 棋谱加密因子(终点)
    bKey = HEAD_KeyXYt
    keys.KeyXYt = (
        (((((bKey * bKey) * 3 + 9) * 3 + 8) * 2 + 1) * 3 + 8) * keys.KeyXYf
    ) & 0xFF

    # 注解大小加密因子
    wKey = HEAD_KeysSum * 256 + HEAD_KeyXY
    keys.KeyRMKSize = ((wKey % 32000) + 767) & 0xFFFF

    B1 = (HEAD_KeysSum & HEAD_KeyMask) | HEAD_KeyOrA
    B2 = (HEAD_KeyXY & HEAD_KeyMask) | HEAD_KeyOrB
    B3 = (HEAD_KeyXYf & HEAD_KeyMask) | HEAD_KeyOrC
    B4 = (HEAD_KeyXYt & HEAD_KeyMask) | HEAD_KeyOrD

    keys.FKeyBytes = (B1, B2, B3, B4)
    keys.F32Keys = bytearray(b"[(C) Copyright Mr. Dong Shiwei.]")
    for i, _ in enumerate(keys.F32Keys):
        keys.F32Keys[i] &= keys.FKeyBytes[i % 4]

    return keys


# -----------------------------------------------------#
def _init_chess_board(man_str, version, keys=None):
    """根据文件中存放的棋子布局字节串构造内部的 32 长度数组。

    如果 `keys` 提供了解密因子则按版本和密钥做位置解密与字节变换，
    否则直接拷贝原始布局。
    返回一个长度为 32 的 bytearray，值为 0xFF 表示该位置无子。
    """
    tmpMan = bytearray([0 for x in range(32)])
    man_buff = bytearray(man_str)

    if keys is None:
        for i in range(32):
            tmpMan[i] = man_buff[i]
        return tmpMan

    for i in range(32):
        if version >= 12:
            tmpMan[(keys.KeyXY + i + 1) & 0x1F] = man_buff[i]
        else:
            tmpMan[i] = man_buff[i]

    for i in range(32):
        tmpMan[i] = (tmpMan[i] - keys.KeyXY) & 0xFF
        if tmpMan[i] > 89:
            tmpMan[i] = 0xFF

    return tmpMan


# -----------------------------------------------------#
def _decode_xqf_buff(keys, buff):
    """使用 `keys` 中的 F32Keys 对缓冲区做逐字节的解密变换并返回解密后的 bytes。"""
    nPos = 0x400
    de_buff = bytearray(buff)

    for i in range(len(buff)):
        KeyByte = keys.F32Keys[(nPos + i) % 32]
        de_buff[i] = (de_buff[i] - KeyByte) & 0xFF

    return bytes(de_buff)


# -----------------------------------------------------#
def _read_init_info(buff_decoder, version, keys):
    """读取并返回记录区的注释信息（若存在）。

    对应 XQF 中走子前的初始化注释，低版本和高版本通过不同方式
    存放注释长度，因此对此进行兼容解析。返回注释字符串或 None。
    """
    step_info = buff_decoder.read_bytes(4)

    annote_len = 0
    if version <= 0x0A:
        # 低版本在走子数据后紧跟着注释长度，长度为0则没有注释
        annote_len = buff_decoder.read_int()
    else:
        # 高版本通过flag来标记有没有注释，有则紧跟着注释长度和注释字段
        step_info[2] &= _XQF_STEP_FLAG_MASK
        if step_info[2] & _XQF_STEP_HAS_ANNO:  # 有注释
            annote_len = buff_decoder.read_int() - keys.KeyRMKSize

    return buff_decoder.read_str(annote_len) if (annote_len > 0) else None


# -----------------------------------------------------#
def _parse_step_info_low_version(step_info, buff_decoder):
    """解析低版本走子信息

    Args:
        step_info: 走子信息字节数组
        buff_decoder: 缓冲区解码器

    Returns:
        tuple: (has_next_step, has_var_step, annote_len)
    """
    has_next_step = bool(step_info[2] & 0xF0)
    has_var_step = bool(step_info[2] & 0x0F)
    annote_len = buff_decoder.read_int()

    # 走子起点，落点
    step_info[0] = (step_info[0] - _XQF_MOVE_FROM_OFFSET) & 0xFF
    step_info[1] = (step_info[1] - _XQF_MOVE_TO_OFFSET) & 0xFF

    return has_next_step, has_var_step, annote_len


def _parse_step_info_high_version(step_info, buff_decoder, keys):
    """解析高版本走子信息

    Args:
        step_info: 走子信息字节数组
        buff_decoder: 缓冲区解码器
        keys: 解密密钥

    Returns:
        tuple: (has_next_step, has_var_step, annote_len)
    """
    step_info[2] &= _XQF_STEP_FLAG_MASK
    has_next_step = bool(step_info[2] & _XQF_STEP_HAS_NEXT)
    has_var_step = bool(step_info[2] & _XQF_STEP_HAS_VAR)
    annote_len = 0

    if step_info[2] & _XQF_STEP_HAS_ANNO:
        annote_len = buff_decoder.read_int() - keys.KeyRMKSize

    # 走子起点，落点
    step_info[0] = (step_info[0] - _XQF_MOVE_FROM_OFFSET - keys.KeyXYf) & 0xFF
    step_info[1] = (step_info[1] - _XQF_MOVE_TO_OFFSET - keys.KeyXYt) & 0xFF

    return has_next_step, has_var_step, annote_len


def _read_steps(buff_decoder, version, keys, book, parent_move, board):
    """递归读取走子数据块并将走子构造为 `Book` 中的 `Move` 链。

    解析单个走子记录，根据版本与 keys 解码起点/终点、注释和分支标志，
    对合法走子调用 `board.move` 并插入到走子树；若检测到变招或后续走
    子，则递归读取相应子区块(深度优先遍历)。
    """
    step_info = buff_decoder.read_bytes(4)

    if len(step_info) == 0:
        return

    board_bak = board.copy()

    # 根据版本解析走子信息
    if version <= 0x0A:
        has_next_step, has_var_step, annote_len = _parse_step_info_low_version(
            step_info, buff_decoder
        )
    else:
        has_next_step, has_var_step, annote_len = _parse_step_info_high_version(
            step_info, buff_decoder, keys
        )

    move_from, move_to = _xqf_decode_pos2(step_info)
    annote = buff_decoder.read_str(annote_len) if annote_len > 0 else None

    good_move = parent_move
    fench = board.get_fench(move_from)
    if fench != ".":
        # pylint: disable=duplicate-code
        piece_color = get_fench_color(fench)
        board.set_move_side(piece_color)
        if board.is_valid_move(move_from, move_to):
            curr_move = board.move(move_from, move_to)
            curr_move.annote = annote
            good_move = append_move_to_book(book, curr_move, parent_move)

    if has_next_step:
        _read_steps(buff_decoder, version, keys, book, good_move, board)

    if has_var_step:
        _read_steps(buff_decoder, version, keys, book, parent_move, board_bak)
        book.info["branchs"] += 1


# -----------------------------------------------------#
def _parse_xqf_header(contents):
    """解析 XQF 文件头

    Args:
        contents: 文件内容字节

    Returns:
        dict: 解析后的头信息，包含 version, keys, chess_mans, step_base_buff 等
    """
    (
        magic,
        version,
        crypt_keys,
        ucBoard,
        _ucUn2,
        ucRes,
        _ucUn3,
        ucType,
        _ucUn4,
        ucTitleLen,
        szTitle,
        _ucUn5,
        ucMatchNameLen,
        szMatchName,
        _ucDateLen,
        _szDate,
        _ucAddrLen,
        _szAddr,
        ucRedPlayerNameLen,
        szRedPlayerName,
        ucBlackPlayerNameLen,
        szBlackPlayerName,
        _ucTimeRuleLen,
        _szTimeRule,
        _ucRedTimeLen,
        _szRedTime,
        _ucBlackTime,
        _szBlackTime,
        _ucUn6,
        _ucCommenerNameLen,
        _szCommenerName,
        _ucAuthorNameLen,
        _szAuthorName,
        _ucUn7,
    ) = struct.unpack(
        "<2sB13s32s3sB12sB15sB63s64sB63sB15sB15sB15sB15sB63sB15sB15s32sB15sB15s528s",
        contents[:_XQF_HEADER_SIZE],
    )

    if magic != b"XQ":
        return None

    game_info = _build_xqf_game_info(
        version,
        ucType,
        ucRes,
        ucRedPlayerNameLen,
        szRedPlayerName,
        ucBlackPlayerNameLen,
        szBlackPlayerName,
        ucTitleLen,
        szTitle,
        ucMatchNameLen,
        szMatchName,
    )

    # 解析密钥和棋盘数据
    if version <= 0x0A:
        keys = None
        chess_mans = _init_chess_board(ucBoard, version)
        step_base_buff = XQFBuffDecoder(contents[_XQF_HEADER_SIZE:])
    else:
        keys = _init_decrypt_key(crypt_keys)
        chess_mans = _init_chess_board(ucBoard, version, keys)
        step_base_buff = XQFBuffDecoder(
            _decode_xqf_buff(keys, contents[_XQF_HEADER_SIZE:])
        )

    return {
        "version": version,
        "keys": keys,
        "chess_mans": chess_mans,
        "step_base_buff": step_base_buff,
        "game_info": game_info,
    }


def _build_xqf_game_info(
    version,
    ucType,
    ucRes,
    ucRedPlayerNameLen,
    szRedPlayerName,
    ucBlackPlayerNameLen,
    szBlackPlayerName,
    ucTitleLen,
    szTitle,
    ucMatchNameLen,
    szMatchName,
):
    """构建 XQF 游戏信息字典

    Args:
        version: XQF 版本
        ucType: 游戏类型
        ucRes: 游戏结果
        ucRedPlayerNameLen: 红方玩家名长度
        szRedPlayerName: 红方玩家名
        ucBlackPlayerNameLen: 黑方玩家名长度
        szBlackPlayerName: 黑方玩家名
        ucTitleLen: 标题长度
        szTitle: 标题
        ucMatchNameLen: 比赛名长度
        szMatchName: 比赛名

    Returns:
        dict: 游戏信息字典
    """
    game_info = {}
    game_info["source"] = "XQF"
    game_info["version"] = version
    game_info["type"] = ucType + 1

    if ucRes <= 4:  # It's really some file has value 4
        game_info["result"] = GAME_RESULT_MAP[ucRes]
    else:
        print("Bad Result  ", ucRes)
        game_info["result"] = "*"

    if ucRedPlayerNameLen > 0:
        try:
            game_info["red_player"] = szRedPlayerName[:ucRedPlayerNameLen].decode(
                "GB18030"
            )
        except (UnicodeDecodeError, ValueError):
            pass

    if ucBlackPlayerNameLen > 0:
        try:
            game_info["black_player"] = szBlackPlayerName[:ucBlackPlayerNameLen].decode(
                "GB18030"
            )
        except (UnicodeDecodeError, ValueError):
            pass

    if ucTitleLen > 0:
        try:
            game_info["title"] = szTitle[:ucTitleLen].decode("GB18030")
        except (UnicodeDecodeError, ValueError):
            pass

    if ucMatchNameLen > 0:
        try:
            game_info["event"] = szMatchName[:ucMatchNameLen].decode("GB18030")
        except (UnicodeDecodeError, ValueError):
            pass

    return game_info


def _build_xqf_board(chess_mans):
    """根据棋子布局构造棋盘

    Args:
        chess_mans: 棋子位置数据

    Returns:
        ChessBoard: 构造好的棋盘
    """
    board = ChessBoard()
    chessman_kinds = "RNBAKABNRCCPPPPP"
    for side in range(2):
        for man_index in range(16):
            man_pos = chess_mans[side * 16 + man_index]
            if man_pos == 0xFF:
                continue
            pos = _xqf_decode_pos(man_pos)
            fen_ch = chr(ord(chessman_kinds[man_index]) + side * 32)
            board.put_fench(fen_ch, pos)

    return board


# -----------------------------------------------------#
def read_from_xqf(full_file_name, book_class, _read_annotation=True):
    """从 `.xqf` 文件读取并解析为 `Book` 对象。

    该函数负责读取文件头、根据版本决定是否需要解密、构造初始棋盘，
    读取棋谱注释并递归解析走子数据块，最终返回填充完毕的 `Book`。

    参数:
        full_file_name (str): XQF 文件路径
        book_class: Book 类，用于创建棋谱实例
        read_annotation (bool): 是否读取注释

    返回:
        Book | None: 成功返回 `Book`，若文件格式不匹配返回 None
    """
    with open(full_file_name, "rb") as f:
        contents = f.read()

    header = _parse_xqf_header(contents)

    if header is None:
        return None

    board = _build_xqf_board(header["chess_mans"])
    game_annotation = _read_init_info(
        header["step_base_buff"], header["version"], header["keys"]
    )

    book = book_class(board, game_annotation)

    book.info.update(header["game_info"])

    _read_steps(
        header["step_base_buff"],
        header["version"],
        header["keys"],
        book,
        None,
        board,
    )

    if book.first_move:
        book.init_board.set_move_side(book.first_move.board_before._move_side)
    else:
        book.init_board.set_move_side(SIDE_RED)

    book.info["move_side"] = str(book.init_board._move_side)

    return book


# -----------------------------------------------------#
def _encode_xqf_pos(pos):
    return pos[0] * 10 + pos[1]


# -----------------------------------------------------#
class XQMove:
    """表示一步棋及其变招。"""

    def __init__(
        self,
        start_pos: Tuple[int, int],
        end_pos: Tuple[int, int],
        annote: str = "",
        has_variation=False,
    ):
        self.start_pos = start_pos  # (x, y) 元组
        self.end_pos = end_pos  # (x, y) 元组
        self.annote = annote
        self.has_variation = has_variation


# -----------------------------------------------------#
class XQFWriter:
    """从 `Book` 对象写入 XQF 格式文件的写入器。"""

    def __init__(self, book):
        self.book = book
        self.header = bytearray(b"\x00" * 1024)  # 头部固定1024字节

        # 设置文件标记和版本
        self._set_bytes(0, b"XQ")  # 文件标记
        self.header[2] = 0x0A  # 版本号 1.0

        # 设置默认初始局面
        self.set_initial_position()

        # 设置默认结果和类型
        self.set_result(0x00)  # 默认未知结果
        self.set_game_type(0x00)  # 默认全局文件

        # 设置棋局信息
        self.set_title(book.info["title"])
        self.set_event(book.info["event"])
        self.set_date(book.info["date"])
        self.set_location(book.info["location"])
        self.set_red_player(book.info["red_player"])
        self.set_black_player(book.info["black_player"])
        self.set_commentator(book.info["commentator"])
        self.set_author("cchess")

    def _set_bytes(self, offset: int, data: bytes):
        """在指定偏移量设置字节数据"""
        for i, byte in enumerate(data):
            self.header[offset + i] = byte

    def _set_string(self, offset: int, text: str, max_length: int):
        """设置字符串字段"""
        if not text:
            self.header[offset] = 0
            return

        # 转换为GBK编码（XQF使用GBK编码）
        try:
            encoded = text.encode("gbk")
        except (UnicodeEncodeError, LookupError):
            encoded = text.encode("gbk", errors="ignore")

        length = min(len(encoded), max_length - 1)
        self.header[offset] = length
        self._set_bytes(offset + 1, encoded[:length])

    def set_initial_position(self):
        """设置初始局面
        默认初始局面（红方和黑方从右到左排列）
        default_position = [
            0x50, 0x46, 0x3C, 0x32, 0x28, 0x1E, 0x14, 0x0A,  # 红方车马相士帅士相马
            0x00, 0x48, 0x0C, 0x53, 0x3F, 0x2B, 0x17, 0x03,  # 红方车炮炮兵兵兵兵兵
            0x09, 0x13, 0x1D, 0x27, 0x31, 0x3B, 0x45, 0x4F,  # 黑方车马象士将士象马
            0x59, 0x11, 0x4D, 0x06, 0x1A, 0x2E, 0x42, 0x56   # 黑方车炮炮卒卒卒卒卒
        ]
        """
        position = bytearray(32)
        board = self.book.init_board
        pieces_dict = {}
        for key in ["R", "N", "B", "A", "K", "C", "P"]:
            pieces_dict[key] = board.get_fench_positions(key)
            key_lower = key.lower()
            pieces_dict[key_lower] = board.get_fench_positions(key_lower)

        fenchs = "RNBAKABNRCCPPPPP"
        for x in range(2):
            for i, fench in enumerate(fenchs):
                key = fench.lower() if x > 0 else fench
                pos_list = pieces_dict[key]
                pos_index = x * 16 + i
                if len(pos_list) == 0:
                    position[pos_index] = 0xFF
                else:
                    pos = pos_list.pop(0)
                    position[pos_index] = _encode_xqf_pos(pos)

        self._set_bytes(0x0010, bytes(position))

    # XQF 头字段配置：field_name → (offset, max_length)
    _HEADER_FIELDS = {
        "result": (0x0033, 1, "int"),
        "game_type": (0x0040, 1, "int"),
        "title": (0x0050, 63, "str"),
        "event": (0x00D0, 63, "str"),
        "date": (0x0110, 15, "str"),
        "location": (0x0120, 15, "str"),
        "red_player": (0x0130, 15, "str"),
        "black_player": (0x0140, 15, "str"),
        "time_rule": (0x0150, 63, "str"),
        "red_time": (0x0190, 15, "str"),
        "black_time": (0x01A0, 15, "str"),
        "commentator": (0x01D0, 15, "str"),
        "author": (0x01E0, 15, "str"),
    }

    def set_field(self, field_name: str, value) -> None:
        """通用头字段设置方法。

        Args:
            field_name: 字段名（如 'title', 'event' 等）
            value: 字段值（字符串或整数）
        """
        if field_name not in self._HEADER_FIELDS:
            raise ValueError(f"Unknown header field: {field_name}")

        offset, max_length, field_type = self._HEADER_FIELDS[field_name]
        if field_type == "int":
            self.header[offset] = value
        else:
            self._set_string(offset, value, max_length)

    # 向后兼容的薄包装（委托给 set_field）
    def set_result(self, result: int):
        """设置棋局结果"""
        self.set_field("result", result)

    def set_game_type(self, game_type: int):
        """设置棋局类型"""
        self.set_field("game_type", game_type)

    def set_title(self, title: str):
        """设置标题"""
        self.set_field("title", title)

    def set_event(self, event: str):
        """设置比赛名称"""
        self.set_field("event", event)

    def set_date(self, date: str):
        """设置比赛日期"""
        self.set_field("date", date)

    def set_location(self, location: str):
        """设置比赛地点"""
        self.set_field("location", location)

    def set_red_player(self, player: str):
        """设置红方棋手"""
        self.set_field("red_player", player)

    def set_black_player(self, player: str):
        """设置黑方棋手"""
        self.set_field("black_player", player)

    def set_time_rule(self, rule: str):
        """设置用时规则"""
        self.set_field("time_rule", rule)

    def set_red_time(self, time_str: str):
        """设置红方用时"""
        self.set_field("red_time", time_str)

    def set_black_time(self, time_str: str):
        """设置黑方用时"""
        self.set_field("black_time", time_str)

    def set_commentator(self, commentator: str):
        """设置棋谱讲评人"""
        self.set_field("commentator", commentator)

    def set_author(self, author: str):
        """设置文件作者"""
        self.set_field("author", author)

    def _encode_move(self, move: XQMove, is_last) -> Tuple[bytes, bytes]:
        """编码一步棋为XQF格式"""
        start_pos_value = _encode_xqf_pos(move.start_pos)
        end_pos_value = _encode_xqf_pos(move.end_pos)

        # 构建移动记录
        move_record = bytearray(8)
        move_record[0] = start_pos_value + 24  # 起始位置+24
        move_record[1] = end_pos_value + 32  # 目标位置+32

        # 如果是序列中的最后一步或者是棋局的最后一步，则标记为最后一步
        move_record[2] = 0x00

        if move.has_variation:
            move_record[2] |= 0x0F
        if not is_last:
            move_record[2] |= 0xF0

        move_record[3] = 0x00  # 保留字节
        # 处理注解
        annote_data = b""
        if move.annote:
            try:
                annote_data = move.annote.encode("gbk")
            except (UnicodeEncodeError, LookupError):
                annote_data = move.annote.encode("gbk", errors="ignore")

        # 设置注解长度（32位整数，小端序）
        annote_length = len(annote_data)
        move_record[4:8] = struct.pack("<I", annote_length)

        return bytes(move_record + annote_data)

    def save(self, file_name):
        """将 Book 数据序列化并保存到指定 XQF 文件。"""
        with open(file_name, "wb") as f:
            move_lines = []
            lines = self.book.dump_moves(is_tree_mode=True)
            for line in lines:
                w_line = []
                for _index, move in enumerate(line["moves"]):
                    has_variation = move.variation_next is not None
                    w_line.append(
                        XQMove(move.pos_from, move.pos_to, move.annote, has_variation)
                    )
                move_lines.append(w_line)

            f.write(self.header)

            if len(move_lines) == 0:
                # 只有初始局面，没有着法记录
                f.write(b"\x18\x20\x00\xff\x00\x00\x00\x00")
                return

            # 有棋谱记录
            f.write(b"\x18\x20\xf0\xff\x00\x00\x00\x00")
            for line in move_lines:
                for i, move in enumerate(line):
                    is_last = i == len(line) - 1
                    move_record = self._encode_move(move, is_last)
                    # 写入招法记录
                    f.write(move_record)
