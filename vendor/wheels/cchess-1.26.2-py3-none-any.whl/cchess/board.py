"""Copyright (C) 2024  walker li <walker8088@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.


中国象棋棋盘模块

提供棋盘数据结构、走法生成、局面检测等核心功能。

主要类：
- ChessBoard: 棋盘核心类，存储棋子分布并提供走子/检测规则
- ChessBoardOneHot: 棋盘独热编码表示（用于机器学习）

核心功能：
- FEN 局面解析与序列化（from_fen / to_fen）
- 走法生成与验证（create_moves / is_valid_move）
- 将军/将死检测（is_checking / is_checkmate）
- 规范局面转换（normalized / denormalize_pos）
- Zobrist 哈希计算（zhash）

设计模式：
- 使用规范局面（normalized board）统一红黑方走法处理
- 攻击矩阵缓存减少重复计算
- 增量更新与完整快照结合的状态管理
"""

from typing import Iterator, List, Optional, Tuple

from .common import (
    FEN_CHAR_SET,
    FEN_NUM_SET,
    SIDE_ANY,
    SIDE_BLACK,
    SIDE_RED,
    _detect_move_side_from_text,
    _normalize_move_str,
    fench_to_txt_name,
    get_fench_color,
    iccs2pos,
    load_json,
    next_side,
    swap_fench,
)
from .exception import CChessError
from .move import Move, MoveInfo, MoveNotation
from .piece import (
    create_moves as piece_create_moves,
)
from .piece import (
    is_valid_move as piece_is_valid_move,
)
from .piece import (
    text_move_to_pos,
)
from .zhash_data import Z_HASH_C90, Z_HASH_TABLE, Z_MAP_PIECES, Z_RED_KEY

# -----------------------------------------------------#
_limit_king_y = {SIDE_ANY: (), SIDE_RED: (0, 1, 2), SIDE_BLACK: (7, 8, 9)}

# -----------------------------------------------------#
_text_board = [
    #'  1   2   3   4   5   6   7   8   9 ',
    "9 ┌───┬───┬───┬───┬───┬───┬───┬───┐ ",
    "  │   │   │   │ ＼│／ │   │   │   │ ",
    "8 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │   │　 │   │ ／│＼ │   │   │   │ ",
    "7 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │   │　 │　 │　 │   │   │   │   │ ",
    "6 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │　 │　 │   │   │   │   │   │   │ ",
    "5 ├───┴───┴───┴───┴───┴───┴───┴───┤ ",
    "  │　                             │ ",
    "4 ├───┬───┬───┬───┬───┬───┬───┬───┤ ",
    "  │　 │　 │   │   │   │　 │　 │　 │ ",
    "3 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │   │　 │　 │　 │   │   │   │   │ ",
    "2 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │   │   │   │ ＼│／ │　 │　 │　 │ ",
    "1 ├───┼───┼───┼───┼───┼───┼───┼───┤ ",
    "  │   │　 │   │ ／│＼ │　 │   │   │ ",
    "0 └───┴───┴───┴───┴───┴───┴───┴───┘ ",
    "   ",
    "  a   b   c   d   e   f   g   h   i ",
    "  0   1   2   3   4   5   6   7   8 ",
    #'  九  八  七  六  五  四  三  二  一',
    #'',
]


# -----------------------------------------------------#
def _pos_to_text_board_pos(pos):
    """将棋盘坐标 (x,y) 转换为文本画板中字符位置。

    参数:
        pos (tuple): 棋盘坐标 (x, y)，x 范围 0-8，y 范围 0-9。

    返回:
        tuple: 文本画板中的 (col, row) 索引，可用于字符串替换绘制棋子。
    """
    return (4 * pos[0] + 2, (9 - pos[1]) * 2)


# -----------------------------------------------------#
class ChessBoard:
    """棋盘核心类：存储棋子分布并提供走子/检测规则的工具方法。

    该类提供加载/导出 FEN、生成走子、检查将军/将死等功能。
    """

    def __init__(self, fen: str = "") -> None:
        """使用可选的 FEN 字符串初始化棋盘。

        参数:
            fen: 初始局面 FEN（缺省为空表示默认空棋盘或初始局面）。
        """
        # 初始化所有实例属性
        self._board: List[List[str]] = [["." for _ in range(9)] for _ in range(10)]
        self._move_side = SIDE_ANY
        # 攻击矩阵缓存
        self._red_attacks: List[List[bool]] = [
            [False for _ in range(9)] for _ in range(10)
        ]
        self._black_attacks: List[List[bool]] = [
            [False for _ in range(9)] for _ in range(10)
        ]
        self._attack_matrix_dirty = True

        # 如果有 FEN，加载它
        if fen:
            self.from_fen(fen)

    def clear(self) -> "ChessBoard":
        """清空棋盘并将走子方设为任意颜色（`SIDE_ANY`）。"""
        # 重置棋盘
        for y in range(10):
            for x in range(9):
                self._board[y][x] = "."

        # 重置走子方
        self._move_side = SIDE_ANY

        # 重置攻击矩阵
        for y in range(10):
            for x in range(9):
                self._red_attacks[y][x] = False
                self._black_attacks[y][x] = False

        self._attack_matrix_dirty = True

        return self

    def move_side(self):
        """获取当前走子方（整数颜色值）"""
        return self._move_side

    def set_move_side(self, value) -> "ChessBoard":
        """设置走子方，支持整数"""
        if value > 3:
            raise CChessError(f"Invalid move side: {value}")
        self._move_side = value
        return self

    def copy(self) -> "ChessBoard":
        """返回棋盘的副本。"""
        b = self.__class__()
        b._board = [row[:] for row in self._board]
        b._red_attacks = [row[:] for row in self._red_attacks]
        b._black_attacks = [row[:] for row in self._black_attacks]
        b._attack_matrix_dirty = self._attack_matrix_dirty
        b.set_move_side(self._move_side)
        return b

    def from_board(self, b: "ChessBoard") -> "ChessBoard":
        """从另一个ChessBoard Copy属性"""
        self._board = [row[:] for row in b._board]
        self._move_side = b._move_side
        # 复制攻击矩阵缓存
        self._red_attacks = b._red_attacks
        self._black_attacks = b._black_attacks
        self._attack_matrix_dirty = b._attack_matrix_dirty

        return self

    def mirror(self) -> "ChessBoard":
        """返回新棋盘: 沿竖直中线镜像（左右翻转）。"""
        b = self.copy()
        b._board = [[self._board[y][8 - x] for x in range(9)] for y in range(10)]
        b._attack_matrix_dirty = True
        return b

    def flip(self) -> "ChessBoard":
        """返回新棋盘: 绕横轴翻转（上下翻转）+ 沿竖直中线镜像（左右翻转）。"""
        b = self.copy()
        b._board = [[self._board[9 - y][8 - x] for x in range(9)] for y in range(10)]
        b._attack_matrix_dirty = True
        return b

    def swap(self) -> "ChessBoard":
        """返回新棋盘: 交换棋子大小写（红黑互换）。

        大写表示红方、小写表示黑方。该方法将所有棋子字母大小写取反，
        同时切换走子方（调用 `next()`）。
        """

        b = self.copy()
        b._board = [
            [swap_fench(self._board[y][x]) for x in range(9)] for y in range(10)
        ]

        b._move_side = next_side(self._move_side)
        b._attack_matrix_dirty = True

        return b

    def is_mirror(self):
        """判断当前棋盘是否关于竖中线对称（镜像局面）。"""
        board = self._board  # 局部变量引用，减少属性访问
        for y in range(10):  # 遍历所有行
            row = board[y]  # 获取当前行的引用
            for x in range(5):  # 只需要比较左半部分 (x=0..4)
                left_fench = row[x]
                right_fench = row[8 - x]

                # 简化判断逻辑：直接比较棋子是否相等（'.' == '.' 为 True）
                if left_fench != right_fench:
                    return False
        return True

    def normalized(self):
        """返回规范局面：当前走子方始终视为红方。

        如果当前是黑方走子，返回 swap().flip() 后的棋盘。
        如果当前是红方走子，返回棋盘的副本。

        返回:
            ChessBoard: 规范局面棋盘
        """
        if self._move_side == SIDE_BLACK:
            return self.swap().flip()
        return self.copy()

    def is_normalized(self):
        """判断当前是否为规范局面（红方走子）。"""
        return self._move_side == SIDE_RED

    def denormalize_pos(self, pos):
        """将规范局面坐标转换回原局面。

        规范局面中：原点在左下角，x 向右，y 向上
        黑方视角：需要 flip 回去，坐标变换为 (8-x, 9-y)
        红方视角：直接返回原坐标（因为规范化棋盘已经是红方走子）

        参数:
            pos: 规范局面中的坐标 (x, y)

        返回:
            tuple: 原局面中的坐标
        """
        # 如果当前棋盘已经是规范局面（红方走子），则原棋盘也是红方走子
        if self.is_normalized():
            return pos
        # 否则原棋盘是黑方走子，需要应用 flip 变换
        return (8 - pos[0], 9 - pos[1])

    def _validate_pos(self, pos):
        """验证坐标是否在棋盘范围内。"""
        if not (0 <= pos[0] <= 8 and 0 <= pos[1] <= 9):
            raise ValueError(f"Position {pos} out of board bounds (0-8, 0-9)")

    # xx_fench 函数操作fen_char而不是Pieces类
    def put_fench(self, fench, pos):
        """在指定位置放置棋子（不做合法性检查）。

        参数:
            fench (str): 棋子字符，例如 'K' 或 'p'，'.' 表示移除棋子
            pos (tuple): 目标坐标 (x, y)

        返回:
            self（支持链式调用）
        """
        self._validate_pos(pos)
        self._board[pos[1]][pos[0]] = fench
        self._attack_matrix_dirty = True
        return self

    def pop_fench(self, pos):
        """移除并返回指定位置的棋子（若为空则返回 None）。"""
        self._validate_pos(pos)
        fench = self._board[pos[1]][pos[0]]
        self._board[pos[1]][pos[0]] = "."
        self._attack_matrix_dirty = True
        return fench

    def get_fench(self, pos):
        """返回指定位置的棋子字符。"""
        self._validate_pos(pos)
        return self._board[pos[1]][pos[0]]

    def occupied(self, pos):
        """检查指定位置是否有棋子。

        参数:
            pos: 坐标 (x, y)

        返回:
            SIDE_RED: 如果该位置有红方棋子
            SIDE_BLACK: 如果该位置有黑方棋子
            None: 如果该位置为空

        示例:
            if board.occupied((4, 4)) == SIDE_RED:
                print("红方棋子")
            elif board.occupied((4, 4)) == SIDE_BLACK:
                print("黑方棋子")
            else:
                print("空位")
        """
        fench = self._board[pos[1]][pos[0]]
        if fench == ".":
            return None
        return SIDE_RED if fench.isupper() else SIDE_BLACK

    def get_fench_positions(self, fench):
        """返回棋盘上所有与给定 fench 相同的坐标列表。"""
        positions = []
        for x in range(9):
            for y in range(10):
                if self._board[y][x] == fench:
                    positions.append((x, y))
        return positions

    def get_fench_positions_v_line(self, fench, x):
        """返回指定列 x 上匹配 fench 的所有坐标。"""
        positions = []
        for y in range(10):
            if self._board[y][x] == fench:
                positions.append((x, y))
        return positions

    def get_all_fench_positions(self, color=None):
        """生成器：遍历棋盘并产出 (fench, pos) 元组。

        参数:
            color (int|None): 若指定，仅返回该颜色的棋子。

        返回:
            迭代器，产出 (fench, (x, y)) 元组
        """
        for x in range(9):
            for y in range(10):
                fench = self._board[y][x]
                if fench == ".":
                    continue
                if color is None:
                    yield (fench, (x, y))
                else:
                    if get_fench_color(fench) == color:
                        yield (fench, (x, y))

    def get_king_pos(self, color):
        """查找并返回指定颜色的王的坐标，找不到返回 None。

        参数:
            color (int): 指定要查找的颜色。

        返回:
            tuple: 王的坐标 (x, y)，找不到返回 None
        """

        for x in (3, 4, 5):
            for y in _limit_king_y[color]:
                fench = self._board[y][x]
                if fench != "." and fench.lower() == "k":
                    return (x, y)
        return None

    # Move 相关
    def is_valid_move(self, pos_from: Tuple[int, int], pos_to: Tuple[int, int]) -> bool:
        """只进行最基本的走子规则检查，不对每个子的规则进行检查，以加快文件加载之类的速度。"""

        # Check pos_from bounds
        if not 0 <= pos_from[0] <= 8:
            return False
        if not 0 <= pos_from[1] <= 9:
            return False

        # Check pos_to bounds
        if not 0 <= pos_to[0] <= 8:
            return False
        if not 0 <= pos_to[1] <= 9:
            return False

        fench_from = self._board[pos_from[1]][pos_from[0]]
        if fench_from == ".":
            return False

        from_color = get_fench_color(fench_from)

        if self._move_side not in (SIDE_ANY, from_color):
            return False

        fench_to = self._board[pos_to[1]][pos_to[0]]
        if fench_to != ".":
            to_color = get_fench_color(fench_to)
            if from_color == to_color:
                return False

        # 使用函数式 API 检查走法合法性
        return piece_is_valid_move(self, fench_from, pos_from, pos_to)

    def _move_piece(
        self, pos_from: Tuple[int, int], pos_to: Tuple[int, int]
    ) -> Tuple[Optional[str], Optional[str]]:
        """在内部执行棋子移动（不做合法性检查），并返回（被移动的fench，被吃子的fench) 。"""
        moving_fench = self._board[pos_from[1]][pos_from[0]]
        captured_fench = self._board[pos_to[1]][pos_to[0]]
        self._board[pos_to[1]][pos_to[0]] = moving_fench
        self._board[pos_from[1]][pos_from[0]] = "."
        self._attack_matrix_dirty = True

        return (moving_fench, captured_fench)

    def move(
        self, pos_from: Tuple[int, int], pos_to: Tuple[int, int], check: bool = True
    ) -> Optional[Move]:
        """尝试执行走子：若合法则修改棋盘并返回 `Move` 对象，否则返回 None。
        返回的 `Move` 包含移动前后的棋盘快照（独立副本）。"""
        if not self.is_valid_move(pos_from, pos_to):
            return None

        # 1. 创建移动前的棋盘快照
        board_before = self.copy()

        # 记录移动前状态
        prev_attack_matrix_dirty = self._attack_matrix_dirty
        prev_move_side = self._move_side
        moving_fench = self._board[pos_from[1]][pos_from[0]]
        captured_fench = self._board[pos_to[1]][pos_to[0]]
        if captured_fench == ".":
            captured_fench = None

        # 2. 执行移动
        self._move_piece(pos_from, pos_to)

        # 记录移动后状态
        next_attack_matrix_dirty = self._attack_matrix_dirty
        next_move_side = self._move_side

        # 3. 创建移动后的棋盘快照
        board_after = self.copy()

        # 创建 MoveInfo（仍然需要，因为 Move 类需要它）
        move_info = MoveInfo(
            from_pos=pos_from,
            to_pos=pos_to,
            moving_fench=moving_fench,
            captured_fench=captured_fench,
            prev_attack_matrix_dirty=prev_attack_matrix_dirty,
            next_attack_matrix_dirty=next_attack_matrix_dirty,
            prev_move_side=prev_move_side,
            next_move_side=next_move_side,
            board_before=board_before._board,  # 仍然需要数组用于撤销
            board_after=board_after._board,  # 仍然需要数组用于撤销
        )

        # 切换走子方（除非吃掉将帅）
        if captured_fench not in ("k", "K"):
            self._move_side = next_side(self._move_side)

        # 创建 Move 对象，传入棋盘实例
        move = Move(move_info, board_before, board_after)

        if check:
            # 检查将军/将死
            original_move_side = self._move_side
            self._move_side = prev_move_side
            is_checking = self.is_checking()
            move.is_checking = is_checking
            move.is_checkmate = is_checking and self.is_checkmate()
            self._move_side = original_move_side

        return move

    def move_iccs(self, move_str: str, check: bool = True) -> Optional[Move]:
        """根据 ICCS 格式的字符串执行走子，返回 `Move` 或 None。"""
        move_from, move_to = iccs2pos(move_str)
        return self.move(move_from, move_to, check)

    def next_turn(self):
        """切换到下一个走子方并返回新的颜色值（工具方法）。"""
        self._move_side = next_side(self._move_side)
        return self._move_side

    def create_moves(self) -> Iterator[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """生成当前走子方的所有候选走法（每个为 (from, to) 元组）。

        使用规范局面：将黑方走子转换为红方视角处理，简化逻辑。
        """
        is_flipped = not self.is_normalized()
        normalized_board = self.normalized()

        for fench, pos in normalized_board.get_all_fench_positions(SIDE_RED):
            for from_pos, to_pos in piece_create_moves(normalized_board, fench, pos):
                if is_flipped:
                    from_pos = self.denormalize_pos(from_pos)
                    to_pos = self.denormalize_pos(to_pos)
                yield (from_pos, to_pos)

    def create_piece_moves(
        self, pos: Tuple[int, int]
    ) -> Iterator[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """生成指定位置棋子的所有候选走法。

        使用规范局面：将黑方走子转换为红方视角处理，简化逻辑。
        """
        fench = self.get_fench(pos)
        if fench == ".":
            return

        piece_color = get_fench_color(fench)
        if piece_color != self._move_side:
            return

        is_flipped = not self.is_normalized()
        normalized_board = self.normalized()

        # 在规范局面中找到对应位置的棋子
        norm_pos = self.denormalize_pos(pos) if is_flipped else pos
        norm_fench = normalized_board.get_fench(norm_pos)

        if norm_fench:
            for from_pos, to_pos in piece_create_moves(
                normalized_board, norm_fench, norm_pos
            ):
                if is_flipped:
                    from_pos = self.denormalize_pos(from_pos)
                    to_pos = self.denormalize_pos(to_pos)
                yield (from_pos, to_pos)

    def _check_move_for_general(
        self,
        pos_from: Tuple[int, int],
        pos_to: Tuple[int, int],
        check_after_move: bool = True,
    ) -> bool:
        """执行走子后检查将军状态的通用辅助方法。

        参数:
            pos_from: 起始位置
            pos_to: 目标位置
            check_after_move: True 检查移动后己方是否被将军，
                             False 检查移动后是否将军对方

        返回:
            bool: 是否处于将军状态
        """
        # 保存状态
        prev_attack = self._attack_matrix_dirty
        prev_side = self._move_side
        board_before = [row[:] for row in self._board]

        # 执行移动
        self._move_piece(pos_from, pos_to)

        # 检查将军
        if check_after_move:
            self._move_side = next_side(self._move_side)
            checking = self.is_checking()
            self._move_side = prev_side
        else:
            orig = self._move_side
            self._move_side = prev_side
            checking = self.is_checking()
            self._move_side = orig

        # 恢复状态
        self._board = board_before
        self._attack_matrix_dirty = prev_attack
        return checking

    def is_checked_move(
        self, pos_from: Tuple[int, int], pos_to: Tuple[int, int]
    ) -> bool:
        """判断执行给定走子后己方是否处于被将军状态。
        若走子非法，抛出 `CChessError('Invalid Move')`。"""
        if not self.is_valid_move(pos_from, pos_to):
            raise CChessError("Invalid Move")
        return self._check_move_for_general(pos_from, pos_to, check_after_move=True)

    def is_checking_move(
        self, pos_from: Tuple[int, int], pos_to: Tuple[int, int]
    ) -> bool:
        """判断执行该走子后是否对对方形成将军（不切换走子方）。"""
        return self._check_move_for_general(pos_from, pos_to, check_after_move=False)

    def _compute_piece_attacks(self, fench, pos) -> List[Tuple[int, int]]:
        """返回棋子可以攻击到的坐标列表（包括吃子位置）。"""
        attacks = []
        for from_pos, to_pos in piece_create_moves(self, fench, pos):
            attacks.append(to_pos)
        return attacks

    def _get_attack_matrix(self, color: int) -> List[List[bool]]:
        """根据颜色获取对应的攻击矩阵。

        参数:
            color: 颜色值 (SIDE_RED 或 SIDE_BLACK)

        返回:
            List[List[bool]]: 对应的攻击矩阵
        """
        return self._red_attacks if color == SIDE_RED else self._black_attacks

    def _recompute_attack_matrix(self) -> None:
        """重新计算红黑双方的攻击矩阵，并将脏标志设置为 False。"""
        # 清空攻击矩阵
        for y in range(10):
            for x in range(9):
                self._red_attacks[y][x] = False
                self._black_attacks[y][x] = False

        # 遍历所有棋子，填充攻击矩阵
        for fench, pos in self.get_all_fench_positions():
            attacks = self._compute_piece_attacks(fench, pos)
            color = get_fench_color(fench)
            matrix = self._get_attack_matrix(color)
            for x, y in attacks:
                matrix[y][x] = True

        self._attack_matrix_dirty = False

    def is_checking(self) -> bool:
        """判断当前走子方是否对对方构成将军（对方王被攻击）。"""
        if self._attack_matrix_dirty:
            self._recompute_attack_matrix()
        king_pos = self.get_king_pos(next_side(self._move_side))
        if not king_pos:
            return False
        matrix = self._get_attack_matrix(self._move_side)
        return matrix[king_pos[1]][king_pos[0]]

    def is_checkmate(self) -> bool:
        """判断当前局面在对方回合是否为将死（无路可走）。"""
        original_player = self._move_side
        self._move_side = next_side(self._move_side)
        try:
            return self.has_no_legal_moves()
        finally:
            self._move_side = original_player

    def has_no_legal_moves(self) -> bool:
        """判断当前走子方是否没有任何合法且不留被将军的走法（困毙）。"""
        king_pos = self.get_king_pos(self._move_side)
        if not king_pos:
            return True

        for fench, pos in self.get_all_fench_positions(self._move_side):
            for move_it in piece_create_moves(self, fench, pos):
                if self.is_valid_move(move_it[0], move_it[1]):
                    if not self.is_checked_move(move_it[0], move_it[1]):
                        return False

        return True

    def count_x_line_in(self, y: int, x_from: int, x_to: int) -> int:
        """统计同一行 y 上 x_from 与 x_to 之间（不含端点）被占用的格子数。"""
        return sum(1 for f in self.x_line_in(y, x_from, x_to) if f != ".")

    def count_y_line_in(self, x: int, y_from: int, y_to: int) -> int:
        """统计同一列 x 上 y_from 与 y_to 之间（不含端点）被占用的格子数。"""
        return sum(1 for f in self.y_line_in(x, y_from, y_to) if f != ".")

    def x_line_in(self, y: int, x_from: int, x_to: int) -> List[Optional[str]]:
        """返回水平方向上两个 x 之间（不含端点）的格子内容列表。"""
        step = 1 if x_to > x_from else -1
        return [self._board[y][x] for x in range(x_from + step, x_to, step)]

    def y_line_in(self, x: int, y_from: int, y_to: int) -> List[Optional[str]]:
        """返回垂直方向上两个 y 之间（不含端点）的格子内容列表。"""
        step = 1 if y_to > y_from else -1
        return [self._board[y][x] for y in range(y_from + step, y_to, step)]

    def from_fen(self, fen: str) -> "ChessBoard":
        """从简化的 FEN 字符串加载棋盘布局并设置走子方。

        参数:
            fen: FEN 字符串

        返回:
            self（支持链式调用）
        """

        fen = fen.strip()
        if fen == "":
            self.clear()
            return self

        parts = fen.split(" ")
        fen0 = parts[0]
        fen1 = parts[1] if len(parts) > 1 else "w"  # 默认为红方走子

        b = ChessBoard()
        x = 0
        y = 9
        for i, ch in enumerate(fen0):
            if (x > 9) or (y < 0):
                raise CChessError(f"fen:{fen} 行列超出界限:{i}, 列:{x}, 行:{y}")
            if ch == "/":
                x = 0
                y -= 1
            elif ch in FEN_NUM_SET:
                x += int(ch)
            elif ch.lower() in FEN_CHAR_SET:
                b.put_fench(ch, (x, y))
                x += 1
            else:
                raise CChessError(f"fen:{fen} 不合法的fen字符串:{i},[{ch}]")

        self._move_side = SIDE_ANY

        if fen1 == "b":
            b.set_move_side(SIDE_BLACK)
        elif fen1 in ["w", "r"]:
            b.set_move_side(SIDE_RED)
        else:
            raise CChessError(f"fen:{fen} 走子合理的值只包括[w,r,b] 当前值为:{fen1}")

        # 事务性转换
        self.from_board(b)

        return self

    def to_fen(self):
        """将棋盘序列化为简化 FEN 字符串（不含额外信息）。"""
        fen = ""
        count = 0
        for y in range(9, -1, -1):
            for x in range(9):
                fench = self._board[y][x]
                if fench != ".":
                    if count != 0:
                        fen += str(count)
                        count = 0
                    fen += fench
                else:
                    count += 1

            if count > 0:
                fen += str(count)
                count = 0

            if y > 0:
                fen += "/"

        if self._move_side == SIDE_BLACK:
            fen += " b"
        else:
            fen += " w"

        return fen

    def to_full_fen(self) -> str:
        """返回包含占位信息的完整 FEN（方便外部工具兼容）。"""
        return self.to_fen() + " - - 0 1"

    def _parse_move_text(self, move_str: str) -> Optional[list]:
        """解析中文走法文本，返回坐标列表 [(from_pos, to_pos), ...]

        内部实现，直接在 board 上操作，避免额外类实例化。
        """
        move_str = move_str.replace(" ", "")
        text_side = _detect_move_side_from_text(move_str)
        norm = self.normalized()

        norm_move_str = (
            _normalize_move_str(move_str, SIDE_BLACK)
            if text_side == SIDE_BLACK
            else move_str
        )

        # 词法解析：从中文走法文本解析中间表示
        notation = MoveNotation.from_text(norm_move_str)
        if not notation:
            return None

        piece_type = notation.piece_type
        column = notation.column
        direction = notation.direction
        distance = notation.distance
        qualifier = notation.qualifier
        fench = piece_type.upper()
        piece_fench = fench.lower()

        if fench not in {"K", "A", "B", "N", "R", "C", "P"}:
            return None

        # 查找候选棋子
        positions = self._find_piece_positions(
            norm, fench, piece_fench, column, qualifier
        )
        if not positions:
            return None

        # 计算目标坐标（使用函数式 API，直接传递 WXF 格式）
        moves = []
        for pos in positions:
            pos_to = text_move_to_pos(piece_fench, pos, direction, distance)
            if pos_to:
                moves.append((pos, pos_to))

        if not moves:
            return None

        # 反规范化
        if self._move_side == SIDE_BLACK:
            return [
                (self.denormalize_pos(f), self.denormalize_pos(t)) for f, t in moves
            ]
        return moves

    def _find_piece_positions(self, norm, fench, piece_fench, column, qualifier):
        """根据限定词和列查找候选棋子位置（支持 WXF 格式）"""
        if qualifier:
            all_positions = norm.get_fench_positions(fench)
            if not all_positions:
                return []

            if piece_fench in {"r", "c", "n", "p"}:
                all_positions.sort(key=lambda p: p[1], reverse=True)
                return self._select_by_qualifier(all_positions, qualifier)
            return []
        else:
            positions = norm.get_fench_positions_v_line(fench, column)
            if not positions:
                return []
            if len(positions) > 1 and piece_fench not in {"a", "b"}:
                return []
            return positions

    @staticmethod
    def _select_by_qualifier(positions, qualifier):
        """根据限定词从已排序的位置列表中选择一个棋子。"""
        dispatch = {
            "+": lambda p: p[0] if p else None,
            "-": lambda p: p[1] if len(p) > 1 else None,
            ".": lambda p: p[-1] if p else None,
            "f": lambda p: p[0] if p else None,
            "m": lambda p: p[1] if len(p) > 1 else None,
            "b": lambda p: p[-1] if p else None,
        }
        fn = dispatch.get(qualifier)
        if fn:
            result = fn(positions)
            return [result] if result is not None else []

        # WXF 字母限定词：abcde → 索引 0-4
        if qualifier in "abcde":
            idx = ord(qualifier) - ord("a")
            return [positions[idx]] if 0 <= idx < len(positions) else []

        # 数字限定词：1-9 → 索引 0-8
        if qualifier.isdigit():
            idx = int(qualifier) - 1
            return [positions[idx]] if 0 <= idx < len(positions) else []

        return []

    def move_text(self, move_str: str, check: bool = True) -> Optional[Move]:
        """根据中文棋谱文本解析并执行走子，返回 `Move` 或 None。"""
        moves = self._parse_move_text(move_str)
        if not moves:
            return None

        for from_pos, to_pos in moves:
            move = self.move(from_pos, to_pos, check)
            if move is not None:
                return move

        return None

    def zhash(self, fen: Optional[str] = None) -> int:
        """计算当前棋盘的 Zobrist 哈希值。
        可选地传入 `fen` 先加载局面再计算哈希，返回一个带符号的整数哈希值。
        """
        if fen:
            self.from_fen(fen)

        key = 0
        for y in range(10):
            for x in range(9):
                square = Z_HASH_C90[x + (9 - y) * 9]
                letter = self.get_fench((x, y))
                if letter in Z_MAP_PIECES:
                    chess = Z_MAP_PIECES[letter]
                    key ^= Z_HASH_TABLE[chess * 256 + square]

        if self._move_side == SIDE_RED:
            key ^= Z_RED_KEY

        return (key & ((1 << 63) - 1)) - (key & (1 << 63))

    def detect_move_pieces(
        self, new_board: "ChessBoard"
    ) -> Tuple[List[Tuple[int, int]], List[Tuple[int, int]]]:
        """比较当前棋盘与 `new_board` 并返回变化位置元组 (from_positions, to_positions)。"""
        p_from = []
        p_to = []
        for x in range(9):
            for y in range(10):
                p_old = self.get_fench((x, y))
                p_new = new_board.get_fench((x, y))
                # same
                if p_old == p_new:
                    continue
                # move from
                if p_new == ".":
                    p_from.append((x, y))
                # move_to
                else:
                    p_to.append((x, y))
        return (p_from, p_to)

    def create_move_from_board(
        self, new_board: "ChessBoard"
    ) -> Optional[Tuple[Tuple[int, int], Tuple[int, int]]]:
        """尝试从两个棋盘状态推断唯一的一步走法，返回 (from, to) 或 None。"""
        p_froms, p_tos = self.detect_move_pieces(new_board)
        if (len(p_froms) == 1) and (len(p_tos) == 1):
            p_from = p_froms[0]
            p_to = p_tos[0]
            if self.is_valid_move(p_from, p_to):
                return (p_from, p_to)
        return None

    def text_view(self):
        """棋盘文字显示, 空位置显示为'.'"""
        return "\n".join(self._board)

    def print_view(self):
        """将棋盘渲染为文本画板（返回字符串列表）。"""
        board_str = _text_board[:]

        y = 0
        for line in self._board:
            x = 8
            for ch in line[::-1]:
                if ch != ".":
                    pos = _pos_to_text_board_pos((x, y))
                    new_text = (
                        board_str[pos[1]][: pos[0]]
                        + fench_to_txt_name(ch)
                        + board_str[pos[1]][pos[0] + 2 :]
                    )
                    board_str[pos[1]] = new_text
                x -= 1
            y += 1

        return board_str

    def __str__(self):
        """__str__ 方法。"""
        return self.to_fen()

    def __repr__(self):
        """__repr__ 方法。"""
        return self.to_fen()

    def __eq__(self, other):
        """__eq__ 方法。"""
        if isinstance(other, str):
            return self.to_fen() == other
        if isinstance(other, ChessBoard):
            return self.to_fen() == other.to_fen()
        return False


# -----------------------------------------------------#
class ChessBoardOneHot(ChessBoard):
    """基于 `ChessBoard` 的独热编码棋盘表示。"""

    def __init__(self, fen="", chess_dict=None):
        """"""
        super().__init__(fen)
        self.__chess_dict = chess_dict

    def load_one_hot_dict(self, file):
        """从 JSON 文件加载棋子到独热向量的映射。"""
        self.__chess_dict = load_json(file) or {}
        self.__chess_dict[None] = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    def get_one_hot_board(self) -> list:
        """依据`self.__chess_dict`对棋子进行独热编码
        :return: 一个列表，将棋子进行独热编码后的棋盘
        """
        one_hot_board = []
        for row in self._board.copy():
            temp = []
            for cell in row:
                temp.append(
                    self.__chess_dict.get(
                        cell, [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                    )
                )
            one_hot_board.append(temp)
        return one_hot_board

    def chess_dict(self):
        """获取棋子-独热编码的映射
        :return: 字典，棋子-独热编码的映射
        """
        return self.__chess_dict.copy()


# -----------------------------------------------------#
# 模块级 FEN 变换函数（避免从 common.py 导入 board 导致循环导入）
def fen_mirror(fen: str) -> str:
    """返回 FEN 字符串的水平镜像版本（左右翻转）。"""
    return ChessBoard(fen).mirror().to_fen()


def fen_flip(fen: str) -> str:
    """返回 FEN 字符串的垂直翻转版本（上下翻转）。"""
    return ChessBoard(fen).flip().to_fen()


def fen_swap(fen: str) -> str:
    """返回 FEN 字符串的交换版本（红黑互换）。"""
    return ChessBoard(fen).swap().to_fen()
